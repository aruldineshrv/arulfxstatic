import { Component, OnInit, OnChanges } from '@angular/core';
import * as Highcharts from "highcharts/highmaps";
import Drilldown from 'highcharts/modules/drilldown';
Drilldown(Highcharts);

declare var require: any;

@Component({
  selector: 'my-app',
  templateUrl: './app.component.html',
  styleUrls: [ './app.component.css' ]
})
export class AppComponent implements OnInit {
  Highcharts;
  chartConstructor = "mapChart";
  chartOptions;
  drilldown: any;
  properties: any;
  value: any;

  constructor() {}

  ngOnInit() {
    this.Highcharts = Highcharts;
    const caMapData = require("@highcharts/map-collection/countries/us/us-all.geo.json");
    const caMap = Highcharts.geojson(caMapData);

    // Set a random value on map
    caMap.forEach((el: any, i) => {
      el.value = i;
      el.drilldown = el.properties["hc-key"];
    });

    this.chartOptions = {
      chart: {
        height: (8 / 16) * 100 + "%",
        events: {
          drilldown(e) {
            console.log("Clicked");
            const chart = this as any;
            const mapKey = "countries/us/" + e.point.drilldown + "-all";
            console.log("mapKey>>>>",e.point);
            console.log("mapKey>>>>",mapKey);
            const mapData = require(`@highcharts/map-collection/${mapKey}.geo.json`);
            const provinceData = Highcharts.geojson(mapData);
            provinceData.forEach((el: any, i) => {
              el.value = i;
            });
            chart.addSeriesAsDrilldown(e.point, {
              name: e.point.name,
              data: provinceData,
              events: {
                onclick(e) {
                  console.log("ssssssssss");
                }
              },    
              dataLabels: {
                enabled: true
              }
            });
            chart.setTitle(null, { text: e.point.name });
          },
          drillup() {
            const chart = this as any;
          }
          ,
          click(e) {
            console.log(e);
          }
        }
      },
      title: {
        text: ""
      },
      colorAxis: {
        min: 0,
        minColor: "#E6E7E8",
        maxColor: "#417BCC"
      },

      mapNavigation: {
        enabled: true,
        buttonOptions: {
          verticalAlign: "bottom"
        }
      },
      plotOptions: {
        map: {
          states: {
            hover: {
              color: "#F8BA03"
            }
          }
        },
        point: {
          events: {
            onclick: function(oEvent) {
              console.log("AAAAAAAASSS");
              console.log(oEvent); 
            }
          }
         }
      },
      series: [
        {
          name: "United States of America",
          data: caMap
        }
      ],
      drilldown: {}
    };
  }
    
}